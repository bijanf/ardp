Submission bundle
=================

Manuscript
  Main.tex                 master file (\input{sections/...})
  sections/01_abstract_intro.tex
  sections/02_results.tex
  sections/03_discussion.tex
  sections/04_methods.tex   Methods + Extended Data figures and tables
  references.bib            49 entries
  naturemag.bst             bibliography style
  Main.bbl                  pre-built bibliography (compiles without bibtex)
  Main.pdf                  compiled manuscript

Marked-up version
  Main_diff.tex             latexdiff of the pre-review manuscript against this
                            one, flattened to a single file
  Main_diff.pdf             compiled marked-up manuscript

Figures (vector PDF, RGB, sans-serif, 5-7 pt text, 180 mm width)
  figures/Fig1_sign.pdf         sign of F_ovS: time series, block-length
                                envelope, latitude sensitivity
  figures/Fig2_attribution.pdf  the two factors, trend split with intervals,
                                epoch census
  figures/Fig3_mechanism.pdf    limb salinities, salinity trend profile,
                                robustness of the transport share
  figures/Fig4_models.pdf       CMIP6 distribution and forced-response test
  extended_data/ED1a_sss_trend_oras5.pdf
  extended_data/ED1b_sss_trend_glorys12.pdf
  extended_data/ED2_section.pdf  section profiles and limb structure

To compile
  latexmk -pdf Main.tex          (or: pdflatex, bibtex, pdflatex x2)
  latexmk -pdf Main_diff.tex     (self-contained, no \input needed)

Note on the marked-up version: the bibliography is deliberately not diffed, so
the reference list appears unmarked in Main_diff.pdf. Figure changes are not
marked up either; Extended Data Fig. 2 was replaced entirely.
